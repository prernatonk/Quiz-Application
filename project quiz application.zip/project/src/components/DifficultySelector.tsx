import React from 'react';
import { DifficultyLevel } from '../types';
import { Brain, Lightbulb, Flame } from 'lucide-react';

interface DifficultySelectorProps {
  onSelect: (difficulty: DifficultyLevel['name']) => void;
}

const difficultyLevels: DifficultyLevel[] = [
  {
    name: 'easy',
    label: 'Easy',
    description: '5 basic knowledge questions',
    icon: 'lightbulb',
    color: 'emerald'
  },
  {
    name: 'medium',
    label: 'Medium',
    description: '10 intermediate questions',
    icon: 'brain',
    color: 'indigo'
  },
  {
    name: 'hard',
    label: 'Hard',
    description: '15 challenging questions',
    icon: 'flame',
    color: 'rose'
  }
];

const getIcon = (iconName: string, className: string) => {
  switch (iconName) {
    case 'lightbulb':
      return <Lightbulb className={className} />;
    case 'brain':
      return <Brain className={className} />;
    case 'flame':
      return <Flame className={className} />;
    default:
      return null;
  }
};

export const DifficultySelector: React.FC<DifficultySelectorProps> = ({ onSelect }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-4xl">
      {difficultyLevels.map((level) => (
        <button
          key={level.name}
          onClick={() => onSelect(level.name)}
          className={`bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all
            border-2 hover:border-${level.color}-500 flex flex-col items-center text-center`}
        >
          {getIcon(`${level.icon}`, `w-12 h-12 text-${level.color}-500 mb-4`)}
          <h3 className={`text-xl font-bold text-${level.color}-600 mb-2`}>
            {level.label}
          </h3>
          <p className="text-gray-600">{level.description}</p>
        </button>
      ))}
    </div>
  );
};