import React from 'react';
import { Question } from '../types';
import { Brain, CheckCircle2, XCircle } from 'lucide-react';

interface QuizCardProps {
  question: Question;
  selectedAnswer: number | null;
  onSelectAnswer: (index: number) => void;
  showResult: boolean;
}

export const QuizCard: React.FC<QuizCardProps> = ({
  question,
  selectedAnswer,
  onSelectAnswer,
  showResult,
}) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-2xl">
      <div className="flex items-center gap-3 mb-6">
        <Brain className="w-6 h-6 text-indigo-600" />
        <h2 className="text-xl font-semibold text-gray-800">{question.question}</h2>
      </div>
      
      <div className="space-y-3">
        {question.options.map((option, index) => {
          const isSelected = selectedAnswer === index;
          const isCorrect = showResult && index === question.correctAnswer;
          const isWrong = showResult && isSelected && index !== question.correctAnswer;
          
          return (
            <button
              key={index}
              onClick={() => !showResult && onSelectAnswer(index)}
              disabled={showResult}
              className={`w-full text-left p-4 rounded-lg flex items-center justify-between transition-all
                ${isSelected ? 'border-2 border-indigo-600' : 'border border-gray-200'}
                ${isCorrect ? 'bg-green-50 border-green-500' : ''}
                ${isWrong ? 'bg-red-50 border-red-500' : ''}
                ${!showResult && !isSelected ? 'hover:bg-gray-50 hover:border-indigo-300' : ''}
                ${showResult ? 'cursor-default' : 'cursor-pointer'}
              `}
            >
              <span className={`
                ${isCorrect ? 'text-green-700' : ''}
                ${isWrong ? 'text-red-700' : ''}
              `}>{option}</span>
              
              {showResult && isCorrect && (
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              )}
              {showResult && isWrong && (
                <XCircle className="w-5 h-5 text-red-600" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};