import React from 'react';
import { Trophy, RotateCcw } from 'lucide-react';

interface ResultsProps {
  score: number;
  totalQuestions: number;
  onRestart: () => void;
}

export const Results: React.FC<ResultsProps> = ({
  score,
  totalQuestions,
  onRestart,
}) => {
  const percentage = (score / totalQuestions) * 100;
  
  return (
    <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-2xl text-center">
      <div className="flex justify-center mb-6">
        <Trophy className="w-16 h-16 text-yellow-500" />
      </div>
      
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Quiz Completed!</h2>
      
      <div className="text-4xl font-bold text-indigo-600 mb-4">
        {score} / {totalQuestions}
      </div>
      
      <p className="text-lg text-gray-600 mb-8">
        You scored {Math.round(percentage)}% - {
          percentage >= 80 ? 'Excellent!' :
          percentage >= 60 ? 'Good job!' :
          'Keep practicing!'
        }
      </p>
      
      <button
        onClick={onRestart}
        className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors"
      >
        <RotateCcw className="w-5 h-5" />
        Try Again
      </button>
    </div>
  );
};