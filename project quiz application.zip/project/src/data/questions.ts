import { Question } from '../types';

export const questions: Question[] = [
  {
    id: 1,
    question: "What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Madrid"],
    correctAnswer: 2,
    difficulty: 'easy'
  },
  {
    id: 2,
    question: "Which planet is known as the Red Planet?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    correctAnswer: 1,
    difficulty: 'easy'
  },
  {
    id: 3,
    question: "Who painted the Mona Lisa?",
    options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
    correctAnswer: 2,
    difficulty: 'easy'
  },
  {
    id: 4,
    question: "What is the largest ocean on Earth?",
    options: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
    correctAnswer: 3,
    difficulty: 'easy'
  },
  {
    id: 5,
    question: "Which element has the chemical symbol 'Au'?",
    options: ["Silver", "Gold", "Copper", "Aluminum"],
    correctAnswer: 1,
    difficulty: 'easy'
  },
  {
    id: 6,
    question: "What is the square root of 144?",
    options: ["10", "12", "14", "16"],
    correctAnswer: 1,
    difficulty: 'medium'
  },
  {
    id: 7,
    question: "Which scientist developed the theory of general relativity?",
    options: ["Isaac Newton", "Albert Einstein", "Stephen Hawking", "Niels Bohr"],
    correctAnswer: 1,
    difficulty: 'medium'
  },
  {
    id: 8,
    question: "What is the chemical formula for sulfuric acid?",
    options: ["H2SO3", "H2SO4", "H2S2O7", "HSO4"],
    correctAnswer: 1,
    difficulty: 'medium'
  },
  {
    id: 9,
    question: "In which year did World War II end?",
    options: ["1943", "1944", "1945", "1946"],
    correctAnswer: 2,
    difficulty: 'medium'
  },
  {
    id: 10,
    question: "What is the capital of Kazakhstan?",
    options: ["Almaty", "Astana", "Bishkek", "Tashkent"],
    correctAnswer: 1,
    difficulty: 'medium'
  },
  {
    id: 11,
    question: "What is the Schwarzschild radius?",
    options: [
      "The radius of a white dwarf",
      "The boundary of a black hole's event horizon",
      "The distance between galaxies",
      "The radius of a neutron star"
    ],
    correctAnswer: 1,
    difficulty: 'hard'
  },
  {
    id: 12,
    question: "Which of these is not a type of fundamental particle?",
    options: ["Quark", "Lepton", "Meson", "Photon"],
    correctAnswer: 2,
    difficulty: 'hard'
  },
  {
    id: 13,
    question: "What is the half-life of Carbon-14?",
    options: ["4,730 years", "5,730 years", "6,730 years", "7,730 years"],
    correctAnswer: 1,
    difficulty: 'hard'
  },
  {
    id: 14,
    question: "Who proved the incompleteness theorem in mathematical logic?",
    options: ["Kurt Gödel", "David Hilbert", "Bertrand Russell", "Alan Turing"],
    correctAnswer: 0,
    difficulty: 'hard'
  },
  {
    id: 15,
    question: "What is the most abundant isotope of hydrogen?",
    options: ["Protium", "Deuterium", "Tritium", "Hydrogen-4"],
    correctAnswer: 0,
    difficulty: 'hard'
  }
];