import React, { useState } from 'react';
import { questions } from './data/questions';
import { QuizCard } from './components/QuizCard';
import { ProgressBar } from './components/ProgressBar';
import { Results } from './components/Results';
import { DifficultySelector } from './components/DifficultySelector';
import { QuizState } from './types';
import { GraduationCap } from 'lucide-react';

function App() {
  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestionIndex: 0,
    score: 0,
    showResults: false,
    answers: [],
    difficulty: 'easy'
  });

  const filteredQuestions = questions.filter(q => {
    if (quizState.difficulty === 'easy') return q.difficulty === 'easy';
    if (quizState.difficulty === 'medium') return q.difficulty === 'easy' || q.difficulty === 'medium';
    return true; // For hard difficulty, show all questions
  });

  const currentQuestion = filteredQuestions[quizState.currentQuestionIndex];

  const handleDifficultySelect = (difficulty: QuizState['difficulty']) => {
    setQuizState({
      currentQuestionIndex: 0,
      score: 0,
      showResults: false,
      answers: [],
      difficulty
    });
  };

  const handleAnswerSelect = (selectedIndex: number) => {
    const isCorrect = selectedIndex === currentQuestion.correctAnswer;
    
    setQuizState(prev => ({
      ...prev,
      answers: [...prev.answers, selectedIndex],
      score: isCorrect ? prev.score + 1 : prev.score,
    }));

    setTimeout(() => {
      if (quizState.currentQuestionIndex < filteredQuestions.length - 1) {
        setQuizState(prev => ({
          ...prev,
          currentQuestionIndex: prev.currentQuestionIndex + 1,
        }));
      } else {
        setQuizState(prev => ({
          ...prev,
          showResults: true,
        }));
      }
    }, 1500);
  };

  const handleRestart = () => {
    setQuizState({
      currentQuestionIndex: 0,
      score: 0,
      showResults: false,
      answers: [],
      difficulty: 'easy'
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center gap-3 mb-8">
          <GraduationCap className="w-8 h-8 text-indigo-600" />
          <h1 className="text-3xl font-bold text-gray-800">Knowledge Quiz</h1>
        </div>

        {!quizState.difficulty || (!currentQuestion && !quizState.showResults) ? (
          <DifficultySelector onSelect={handleDifficultySelect} />
        ) : !quizState.showResults ? (
          <div className="flex flex-col items-center">
            <ProgressBar
              current={quizState.currentQuestionIndex}
              total={filteredQuestions.length}
            />
            <QuizCard
              question={currentQuestion}
              selectedAnswer={quizState.answers[quizState.currentQuestionIndex] ?? null}
              onSelectAnswer={handleAnswerSelect}
              showResult={quizState.answers[quizState.currentQuestionIndex] !== undefined}
            />
          </div>
        ) : (
          <Results
            score={quizState.score}
            totalQuestions={filteredQuestions.length}
            onRestart={handleRestart}
          />
        )}
      </div>
    </div>
  );
}

export default App;