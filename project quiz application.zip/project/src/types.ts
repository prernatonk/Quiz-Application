export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface QuizState {
  currentQuestionIndex: number;
  score: number;
  showResults: boolean;
  answers: number[];
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface DifficultyLevel {
  name: 'easy' | 'medium' | 'hard';
  label: string;
  description: string;
  icon: string;
  color: string;
}